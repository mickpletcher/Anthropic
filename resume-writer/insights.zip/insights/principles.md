# Resume Writer Insights Library

This file is the authoritative source of principles for the `resume-writer` skill. Every principle here was harvested from a real recruiter, hiring manager, or HR professional. The skill uses these principles to audit and rewrite resumes.

## Format

Each principle follows this structure:

```
## <Principle Name>

**Rule**: <1-2 sentence actionable rule>

**Rationale**: <Why it matters to the recruiter/hiring manager>

**Example violation**: <Bad example, quoted or synthesized>

**Example fix**: <Good example>

**Sources**:
- <Name>, <Title> — <Platform>, <Date>
```

To add new principles, use the skill's "Add Insight" mode.

---

## Lead with project impact, not credentials

**Rule**: Do not open a resume with a stack of certifications. Open with the most impactful project or outcome you have delivered. Certifications belong further down the document.

**Rationale**: Hiring managers care about what you have done with your skills, not whether you passed a test. Certifications are a baseline filter, not a differentiator. Leading with them signals that credentials are your strongest asset, which is a weak opening.

**Example violation**: A ServiceNow architect resume that leads with "CSA Certified, CAD Certified, CIS-HR Certified" before any project history.

**Example fix**: Lead the resume with a headline bullet like "Migrated 200 catalog items in 6 weeks during Fortune 500 ServiceNow consolidation, retiring 4 legacy tools."

**Sources**:
- Brandon Wilson, CTA, MMIS, Founder of OnlyFlows and ServiceNow Practice Lead at Four Dragons — LinkedIn, April 2026

---

## Every bullet must name the thing

**Rule**: Generic bullets like "configured modules" or "improved processes" are worthless. Every bullet must name the specific module, system, process, or artifact involved.

**Rationale**: Vague bullets prevent the recruiter from evaluating the actual scope and technical depth of the work. If you configured ServiceNow modules, say which ones. If you improved a process, name the process. Without specifics, the bullet tells the reader nothing.

**Example violation**: "Configured ServiceNow modules to support business operations."

**Example fix**: "Configured ServiceNow ITSM, HR Service Delivery, and CSM modules, including custom workflows in HRSD for onboarding automation that replaced a 4-step manual process."

**Sources**:
- Brandon Wilson, CTA, MMIS, Founder of OnlyFlows and ServiceNow Practice Lead at Four Dragons — LinkedIn, April 2026

---

## Numbers, everywhere, or you get an interview with nobody

**Rule**: Every bullet that describes an outcome must quantify it. Dollars, percentages, time saved, volume handled, people managed, tickets resolved, latency reduced. No numbers means no impact.

**Rationale**: "Improved incident response" is unverifiable and unmemorable. "Reduced MTTR from 4.2 hours to 1.8 hours across 12,000 monthly incidents" is specific, testable, and immediately tells the hiring manager the scale of environment you worked in.

**Example violation**: "Improved incident response times and reduced ticket backlog."

**Example fix**: "Reduced MTTR from 4.2 hours to 1.8 hours across 12,000 monthly incidents, cutting ticket backlog from 1,800 to under 200 within 90 days."

**Sources**:
- Brandon Wilson, CTA, MMIS, Founder of OnlyFlows and ServiceNow Practice Lead at Four Dragons — LinkedIn, April 2026

---

## Two pages is the ceiling

**Rule**: Resumes longer than two pages get rejected. If you cannot communicate your value in two pages, you cannot communicate it in a 30-minute meeting with a decision maker.

**Rationale**: Recruiters and hiring managers spend less than a minute on the first pass. Length signals inability to prioritize and a reluctance to cut. Senior roles, including architect and executive roles, still fit in two pages when written with discipline.

**Example violation**: A 5-page architect resume that includes every project from the last 15 years with 6-8 bullets each.

**Example fix**: A 2-page architect resume showing the last 10-12 years of work in detail, with earlier roles collapsed into a single "Earlier Experience" line.

**Sources**:
- Brandon Wilson, CTA, MMIS, Founder of OnlyFlows and ServiceNow Practice Lead at Four Dragons — LinkedIn, April 2026

---

## A resume is a sales document, not a job history

**Rule**: A resume should persuade the reader to interview you. It is not a chronological list of every task you have ever performed. Every line must earn its place by making the case that you should be hired.

**Rationale**: Job histories bore recruiters. Sales documents compel them. This principle underlies every other principle in this library: why lead with impact, why quantify, why cut length. A resume that reads like a job description for your past roles has failed.

**Example violation**: "Responsible for managing incident response team and ensuring SLA compliance."

**Example fix**: "Led 7-person incident response team to 99.2% SLA compliance across 12,000 monthly tickets, up from 87% at start of tenure."

**Sources**:
- Brandon Wilson, CTA, MMIS, Founder of OnlyFlows and ServiceNow Practice Lead at Four Dragons — LinkedIn, April 2026

---
