---
name: resume-writer
description: Rewrite and enhance resumes using a persistent library of principles harvested from real recruiters, hiring managers, and HR professionals. Always trigger immediately when the user's message starts with "rw". Also trigger on "resume writer", "rewrite my resume", "enhance my resume", "fix my resume", "review my resume", or any request to improve, audit, or critique a resume. Also trigger when the user pastes a recruiter or hiring manager post (LinkedIn, blog, Reddit) and says "add to my library", "add insight", "rw add", or indicates they want to capture it as a resume principle. Handles paste, .docx, .pdf, and screenshot inputs. Produces a full rewrite AND an itemized audit mapping every change to a specific principle in the library. General-purpose skill that works for any user's resume, not just the skill owner.
---

# Resume Writer

Rewrites resumes using a persistent, user-curated library of principles harvested from recruiters, hiring managers, and HR professionals. Every change made is traceable back to a specific principle in the library.

## Two modes

This skill operates in one of two modes. Detect which one before proceeding.

### Mode 1: Enhance a resume (default)

Triggered when the user provides a resume (pasted, .docx, .pdf, or screenshot) and asks for a rewrite, review, audit, or critique.

Go to the **Enhance Workflow** section.

### Mode 2: Add an insight to the library

Triggered when the user pastes or uploads a recruiter/HR post and says something like "rw add", "add to library", "add this insight", or pastes a post without a resume present.

Go to the **Add Insight Workflow** section.

If in doubt, ask once: "Do you want me to enhance a resume, or add this to your insights library?"

---

## Enhance Workflow

### Step 1: Extract resume text

Match the input type:

- **Pasted text**: Use as-is.
- **.docx**: Use the `docx` skill to read it.
- **.pdf**: Use the `pdf-reading` skill to extract text. If the PDF is image-based (scanned), rasterize pages and read them as images.
- **Screenshot / image**: Read the image directly.

If the text is unreadable or clearly incomplete, stop and ask the user to re-upload.

### Step 2: Load the insights library

Read `insights/principles.md` in full. This is the authoritative source for every critique made in the audit. Do not invent principles that are not in the library — if something is weak but no library principle covers it, flag it in a separate section called "Not-in-library observations" rather than attributing it to a library principle that does not exist.

Also read `references/common-patterns.md` for structural patterns (formatting, length, section order) that do not need individual library entries.

### Step 3: Ask one clarifying question (if needed)

Before rewriting, ask at most ONE question if it materially affects the rewrite:

- If no target role is specified AND the resume is ambiguous: "What role or type of role is this resume targeting?"
- If the user already gave the target role, do not ask.
- Do not ask about tone, format, or style preferences — infer them from the resume itself.

Skip this step entirely if the target is obvious.

### Step 4: Audit the resume

For every bullet, section, and structural element, check it against each principle in the library. Build an internal list of violations in this format:

```
- [Location: Section / bullet N]
- [Principle violated: <principle name from library>]
- [Current text: "<exact quote>"]
- [Issue: <specific problem>]
- [Recommended fix: "<rewritten text>"]
```

Be specific. "Weak bullet" is not a valid issue. "No outcome specified — says 'improved processes' without saying what improved or by how much" is.

### Step 5: Produce the rewrite

Rewrite the full resume applying all recommended fixes. Preserve:

- Contact info exactly as given
- Employer names, job titles, dates exactly as given
- Education details (school, degree, dates)
- Any certifications (keep all, but reorder per library principles)

Rewrite freely:

- Bullet wording, order, and specificity
- Summary / profile section
- Skills section organization
- Section ordering within the resume

Do not invent facts. If a bullet lacks a number and the user did not provide one, rewrite using the strongest truthful framing available — do not fabricate metrics. Flag in the audit that a number is needed and ask the user to supply it.

### Step 6: Produce the output

Deliver three things, in this order:

1. **Itemized audit** — a table or structured list of every change, with columns: Location | Principle | Before | After. Include a "Missing data" section at the end listing any spots where the user needs to supply numbers or details to strengthen the rewrite further.

2. **Rewritten resume** — full text, ready to use. If the input was a .docx, produce a .docx output using the `docx` skill, preserving any letterhead or formatting the user had. If paste or image input, produce Markdown unless the user asks for .docx.

3. **Next steps** — a short list: missing metrics to fill in, recommended follow-ups, and anything flagged in "Not-in-library observations."

---

## Add Insight Workflow

### Step 1: Extract the source

- Paste text: use as-is
- Screenshot: OCR the image, read the text
- URL: fetch the URL if accessible

Capture: who said it (name, title if visible), platform, approximate date, and the raw text.

### Step 2: Extract the principle(s)

A single post may contain multiple principles. Extract each one separately. For each, identify:

- **Principle name** — short, memorable (e.g., "Lead with impact, not credentials")
- **The rule** — 1-2 sentences
- **Rationale** — why the recruiter says it matters
- **Example violation** — quote the bad example if given, otherwise synthesize a realistic one
- **Example fix** — quote the good example if given, otherwise synthesize one
- **Source** — Name, Title, Platform, Date

Skip anything that is opinion without actionable rule (e.g., "I prefer Helvetica" is too weak to be a principle unless it is part of a broader formatting rule).

### Step 3: Check for duplicates

Read the existing `insights/principles.md`. If a principle is already covered, either:

- Skip it and tell the user "already in library as '<existing principle name>'", OR
- Merge it: if the new post strengthens or adds nuance, append the new source to the existing principle and note the additional angle.

Never create near-duplicate entries.

### Step 4: Append to library

Add new principles to `insights/principles.md` using the format shown in that file. Maintain the existing structure. Do not reorder existing entries.

### Step 5: Confirm

Tell the user exactly what was added or merged. Format:

```
Added 2 principles to the library:
1. [Name] — [1-sentence summary]
2. [Name] — [1-sentence summary]

Merged into existing: [Name of existing principle]
Skipped (already covered): [Name]
```

---

## Principles of using this skill

- **Every audit finding must map to a library principle, a pattern in `references/common-patterns.md`, or be clearly flagged as "Not-in-library observation".** Do not invent principles.
- **Never fabricate metrics.** If a bullet needs a number the user did not supply, flag it in the "Missing data" section and rewrite with the strongest truthful framing available.
- **Preserve facts, rewrite framing.** Employers, titles, dates, certifications, and education details are never changed. Everything else is fair game.
- **The library grows over time.** If during a rewrite you notice the user would benefit from a principle not yet captured, mention it: "This weakness maps to a common recruiter complaint I do not have in your library yet. Want to add it?"
- **General-purpose tone.** Do not assume the resume belongs to the skill owner. Match the voice of the existing resume unless the user requests a tone change.
